package toroshu.tomato.deprecated;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import toroshu.tomato.R;

/*
Shows licenses of the 3rd party modules used in the project
*/

public class Credits extends AppCompatActivity {

    WebView creditsView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credits);

//        ButterKnife.bind(this);
//
//        String[] n = {"Android View Animations", "Crouton",
//                "Material Design Library", "Android edittext validator",
//                "Material Dialogs", "Material Drawer",
//                "License Dialog",
//        };
//


    }


}