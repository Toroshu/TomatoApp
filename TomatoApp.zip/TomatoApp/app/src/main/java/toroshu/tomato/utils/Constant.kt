package toroshu.tomato.utils

class Constant {
    companion object {
        val AlreadyRegistered = "AlreadyRegistered"
        val Tomato = "Tomato"
        val Username = "Username"
        val Password = "Password"
        val FirstSuperHero = "FirstSuperHero"
        val SecondSuperHero = "SecondSuperHero"
        val Prefs = "Prefs"
        val ProtectionOn = "ProtectionOn"
        val SimId = "SimId"
        val DisplayAccountConfirmation = "DisplayAccountConfirmation"
        val Pin = "Pin"
        val AlertMode = "AlertMode"
        val NumUpdates = "NumUpdates"
        val Track = "Track"
        val PLAY_SERVICES_RESOLUTION_REQUEST = 9000
        val SavedSims = "SavedSims"
        val Res = "res"

    }
}